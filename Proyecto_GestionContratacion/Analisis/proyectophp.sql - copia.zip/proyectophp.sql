--
-- Base de datos: `proyectophp`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contatos_publicos`
--

CREATE TABLE `contatos_publicos` (
  `idContatos_Publicos` int(11) NOT NULL,
  `Tipo_Proceso` varchar(45) NOT NULL,
  `Estado` enum('Cancelado','En ejecucion','Liquidado') NOT NULL,
  `RC` varchar(45) NOT NULL,
  `Descripcion_Objeto_Contratar` varchar(45) NOT NULL,
  `Cuantia` varchar(45) NOT NULL,
  `Tipo_Contrato` varchar(45) NOT NULL,
  `departamento_Ejecucion` varchar(45) NOT NULL,
  `municipio_ejecucion` varchar(45) NOT NULL,
  `Departamento_Obtenciondocumentos` varchar(45) NOT NULL,
  `Municipio_Obtencion_Documentos` varchar(45) NOT NULL,
  `Direccion_Entrega_Documentos` varchar(45) NOT NULL,
  `Fecha_Hora_Apertura_Proceso` varchar(45) NOT NULL,
  `Observaciones` text,
  `idPersona` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `contatos_publicos`
--

INSERT INTO `contatos_publicos` (`idContatos_Publicos`, `Tipo_Proceso`, `Estado`, `RC`, `Descripcion_Objeto_Contratar`, `Cuantia`, `Tipo_Contrato`, `departamento_Ejecucion`, `municipio_ejecucion`, `Departamento_Obtenciondocumentos`, `Municipio_Obtencion_Documentos`, `Direccion_Entrega_Documentos`, `Fecha_Hora_Apertura_Proceso`, `Observaciones`, `idPersona`) VALUES
(12, 'labora', 'Liquidado', '123', '                                             ', '123', '123', '13', '123', '132', '132', '132', '13', '27', NULL),
(13, '123', 'En ejecucion', 'asss', 'asss', '10000', 'asss', 'casanare', 'casanare', 'casd', 'sd', 'dq', '2017-08-12', NULL, 8),
(14, '123', 'En ejecucion', '123', 'hola', 'hola', '123', 'boyaca', 'paipa', 'Boyacá', 'paipa', 'calle', '2017-08-11', NULL, 8),
(15, 'Laboral', 'Cancelado', 'S-109A', ' 123456dfg                                   ', '20.000.000', 'Vivienda', 'casanare', 'Recetor', 'Casanare', 'Boyaca', 'Alcaldia de Sogamoso', '2017-08-04', '26', NULL),
(16, 'hola', 'En ejecucion', 'hola', 'hola', '20000', 'construir casas', 'boyaca', 'paipa', 'Boyacá', 'paipa', 'calle 25', '2017-08-19', NULL, 27),
(17, 'lab', 'En ejecucion', 'Administrativo', 'documentos', '500000', 'Ad', 'boyaca', 'Sogamoso', 'Boyacá', 'sogamoso', '12783', '2017-08-18', NULL, 28),
(18, 'Laboral', 'En ejecucion', 'Obra', 'Construcción de casas', '20.000.000', 'Contratación directa', 'Casanare', 'Recetor', 'Casanare', 'Yopal', 'Gobernacion de Casanare', '2017-08-04', NULL, 29);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `documentos`
--

CREATE TABLE `documentos` (
  `idDocumentos` int(11) NOT NULL,
  `Nombre` varchar(45) NOT NULL,
  `Descripcion` varchar(200) NOT NULL,
  `Tipo` varchar(45) NOT NULL,
  `Version` varchar(45) NOT NULL,
  `Fecha_Publicacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Documento` varchar(200) NOT NULL,
  `idLicitacion` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `documentos`
--

INSERT INTO `documentos` (`idDocumentos`, `Nombre`, `Descripcion`, `Tipo`, `Version`, `Fecha_Publicacion`, `Documento`, `idLicitacion`) VALUES
(3, 'documento 1', 'hksjkdh', 'pdf', 'v1.0', '2017-08-04 15:20:43', '../Documentos/1.0123GT04_JavaScript.pdf', 15),
(4, 'PrimeraObra', 'cotización', 'pdf', 'vv1.0', '2017-08-04 17:10:16', '../Documentos/v1.0123GT04_JavaScript.pdf', 19);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresas`
--

CREATE TABLE `empresas` (
  `idEmpresas` int(11) NOT NULL,
  `Razonsocial_contratista` varchar(45) NOT NULL,
  `Identificacion_Contatista` varchar(45) NOT NULL,
  `Pais_Contatrista` varchar(45) NOT NULL,
  `Departamento_Contatista` varchar(45) NOT NULL,
  `Provincia_Contratista` varchar(45) NOT NULL,
  `Direccion_Contratista` varchar(45) NOT NULL,
  `Correo` varchar(45) NOT NULL,
  `Representante_Contaratista` varchar(45) NOT NULL,
  `Identificacion_Representante` varchar(45) NOT NULL,
  `Respuesta` varchar(40) DEFAULT NULL,
  `Estado` varchar(45) NOT NULL,
  `idPersona` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `empresas`
--

INSERT INTO `empresas` (`idEmpresas`, `Razonsocial_contratista`, `Identificacion_Contatista`, `Pais_Contatrista`, `Departamento_Contatista`, `Provincia_Contratista`, `Direccion_Contratista`, `Correo`, `Representante_Contaratista`, `Identificacion_Representante`, `Respuesta`, `Estado`, `idPersona`) VALUES
(7, 'Adsi', '12346566', 'Colombia', 'Casanare', 'Recetor', 'hola amigos', 'Adsi@gmail.com', 'Alejandro', '1234676784894', 'Si', 'Inactivo', 25),
(8, 'Contructora-123', '1234454645', 'Colombia', 'Casanare', 'Yopal', 'Calle 54', 'contructora@gmail.com', 'Lucho', '123121231', 'Si', 'Activo', 26),
(9, 'ADEC', '12334556', 'Colombia', 'Boyaca', 'Sogamoso', 'calle 32', 'a@gmail.com', 'sebastian', '105248223', 'Si', 'Activo', 27),
(10, 'servicios', '3767990', 'colombia', 'Boyaca', 'Sogamoso', 'calle24', 'serv@gmail.com', 'leo', '133567', 'Si', 'Activo', 28);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `licitacion`
--

CREATE TABLE `licitacion` (
  `idLicitacion` int(11) NOT NULL,
  `Fecha_firma_contrato` varchar(45) NOT NULL,
  `Ejecucion_Contrato` varchar(45) NOT NULL,
  `Plazo_Ejecucion_Contrato` varchar(45) NOT NULL,
  `Calificacion` varchar(45) NOT NULL,
  `Estado` enum('Activo','Inactivo') NOT NULL,
  `idPersona` int(10) UNSIGNED DEFAULT NULL,
  `idEmpresas` int(11) DEFAULT NULL,
  `idContatos_Publicos` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `licitacion`
--

INSERT INTO `licitacion` (`idLicitacion`, `Fecha_firma_contrato`, `Ejecucion_Contrato`, `Plazo_Ejecucion_Contrato`, `Calificacion`, `Estado`, `idPersona`, `idEmpresas`, `idContatos_Publicos`) VALUES
(15, '2017-08-08', '2017-08-27', '2017-08-23', '1000', 'Inactivo', 28, 7, 12),
(16, '2017-08-04', '2017-08-04', '2017-08-04', '200', 'Activo', 26, 7, 13),
(17, '2017-08-05', '2017-08-11', '2017-08-26', '200', 'Activo', 27, 9, 16),
(18, '2017-08-19', '2017-08-13', '2017-08-24', '90', 'Activo', 28, 9, 16),
(19, '2017-08-04', '2017-08-04', '2017-10-28', '350', 'Activo', 29, 8, 18);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `persona`
--

CREATE TABLE `persona` (
  `idPersona` int(10) UNSIGNED NOT NULL,
  `Tipo_Documento` enum('C.C','T.I','R.C','C.E','Otros') NOT NULL,
  `Documento` bigint(20) UNSIGNED NOT NULL,
  `Foto` varchar(200) NOT NULL,
  `Fecha_Nacimiento` date NOT NULL,
  `Genero` enum('Masculino','Femenino') NOT NULL,
  `Nombres` varchar(50) NOT NULL,
  `Apellidos` varchar(50) NOT NULL,
  `Telefono` bigint(20) UNSIGNED NOT NULL,
  `Direccion` varchar(60) NOT NULL,
  `Correo` varchar(60) NOT NULL,
  `Contrato_PDF` varchar(200) DEFAULT NULL,
  `NRP` int(10) UNSIGNED DEFAULT NULL,
  `Usuario` varchar(45) NOT NULL,
  `Contrasena` varchar(255) NOT NULL,
  `Estado` enum('Activo','Inactivo') NOT NULL,
  `Cargo` varchar(45) NOT NULL,
  `idSecretarias` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `persona`
--

INSERT INTO `persona` (`idPersona`, `Tipo_Documento`, `Documento`, `Foto`, `Fecha_Nacimiento`, `Genero`, `Nombres`, `Apellidos`, `Telefono`, `Direccion`, `Correo`, `Contrato_PDF`, `NRP`, `Usuario`, `Contrasena`, `Estado`, `Cargo`, `idSecretarias`) VALUES
(8, 'C.C', 1116552281, '../Contratos-Fotos/img.jpg', '1996-10-05', 'Masculino', 'Alejandro', 'Bernal', 3103483907, 'sogamoso', 'a@gmail.com', '../Contratos-Fotos/1116552281GT02_HTML5.pdf', 1212, 'Admin', '123', 'Activo', 'Administrador', 11),
(24, 'C.C', 123456789, '../Contratos-Fotos/123456789123Desert.jpg', '1999-09-16', 'Femenino', 'Kateriin', 'Barrera', 321263278, 'calle falsa', 'katerin@gmail.com', '../Contratos-Fotos/123456789123tecnicas_Instrumentos.pdf', 123, 'Admin2', '123', 'Activo', 'Administrador', 11),
(25, 'C.C', 10012345, '../Contratos-Fotos/10012345123Desert.jpg', '1998-10-12', 'Femenino', 'Dayanna1', 'Rincon', 132445567, 'calle 34 ', 'dayana@gmail.com', NULL, 123456, 'dayanna', '123', 'Activo', 'General', 11),
(26, 'C.C', 1052386154, '../Contratos-Fotos/1052386154123Desert.jpg', '1988-08-15', 'Masculino', 'lucho2', 'cardenas', 3123509510, 'Calle 20', 'lucho@gmail.com', '../Contratos-Fotos/10523861542312IAL_A105-2013.pdf', 123456, 'lucho', '123', 'Activo', 'General', 11),
(27, 'C.C', 12345612, '../Contratos-Fotos/12345612123Desert.jpg', '1998-08-06', 'Masculino', 'Jhoan1', 'Patarroyo', 311591264, 'Paipa', 'jhoan@gmail.com', '../Contratos-Fotos/12345612123112312Ver Certificados.pdf', 12345, 'jhoan', '123', 'Activo', 'General', 11),
(28, 'C.C', 1234566, '../Contratos-Fotos/1234566123Desert.jpg', '1996-08-16', 'Masculino', 'leonardo', 'perez', 312021957, 'callle34', 'leo@gmail.com', '../Contratos-Fotos/1234566123macrosVisualBasicParaExcel.pdf', 67, 'leo', '123', 'Activo', 'Subgeneral', 12),
(29, 'C.C', 11162228121, '../Contratos-Fotos/11162228121123Jellyfish.jpg', '1980-08-03', 'Masculino', 'Fredy', 'Alarcon', 3212132343, 'calle 12-12-15', 'fredy@gmail.com', '../Contratos-Fotos/11162228121123Tecnicas_Procedimientos_Recoleccion.pdf', 123, 'fredy12', '123', 'Activo', 'General', 12);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro_actas`
--

CREATE TABLE `registro_actas` (
  `idRegistro_Actas` int(10) UNSIGNED NOT NULL,
  `Fecha` date NOT NULL,
  `Hora` varchar(10) NOT NULL,
  `Lugar_Reunion` varchar(45) NOT NULL,
  `Puntos_Tratados` varchar(45) NOT NULL,
  `Acuerdos_Tomados` varchar(45) NOT NULL,
  `Observaciones` varchar(45) NOT NULL,
  `idPersona` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `registro_actas`
--

INSERT INTO `registro_actas` (`idRegistro_Actas`, `Fecha`, `Hora`, `Lugar_Reunion`, `Puntos_Tratados`, `Acuerdos_Tomados`, `Observaciones`, `idPersona`) VALUES
(7, '2017-08-16', '22:58', 'Adsi', 'bvbdfvbwifui', 'bvxcghsdg', 'xcvhsdjf', 25);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `secretarias`
--

CREATE TABLE `secretarias` (
  `idSecretarias` int(10) UNSIGNED NOT NULL,
  `Nombre` varchar(45) NOT NULL,
  `Vision` text NOT NULL,
  `Mision` text NOT NULL,
  `Objetivos` text NOT NULL,
  `Telefono` bigint(20) NOT NULL,
  `Direccion` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `secretarias`
--

INSERT INTO `secretarias` (`idSecretarias`, `Nombre`, `Vision`, `Mision`, `Objetivos`, `Telefono`, `Direccion`) VALUES
(11, 'Secretaria De Salud1', 'Salvar gente', 'Ser mejores personas', 'lograr Todas las metas                                                ', 3212634879, 'calle falsa 123'),
(12, 'Secretaria de Agricultura', 'el campo primero', 'hola', 'la meta                                                ', 3123509510, 'sogamoso'),
(13, 'Secretaria de transporte', 'hola', 'hola', 'hola', 3123509510, 'casanare '),
(14, 'Secretaria de Agricultura', 'el campo primero', 'hola1', 'la meta                                                                                                ', 3123509510, 'sogamoso'),
(15, 'Pediatria', 'hola', 'hola', 'tayaytgausg', 31031849, 'carrera 19'),
(16, 'Secretaria de Cultura', 'Promocionar la venta de poker', 'vender cinco carros', 'alcanzar las metas                                                ', 72312421, 'Alcaldia Recetor');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `contatos_publicos`
--
ALTER TABLE `contatos_publicos`
  ADD PRIMARY KEY (`idContatos_Publicos`),
  ADD KEY `fk_Contatos_Publicos_Persona1_idx` (`idPersona`);

--
-- Indices de la tabla `documentos`
--
ALTER TABLE `documentos`
  ADD PRIMARY KEY (`idDocumentos`),
  ADD KEY `fk_documentos_Licitacion` (`idLicitacion`);

--
-- Indices de la tabla `empresas`
--
ALTER TABLE `empresas`
  ADD PRIMARY KEY (`idEmpresas`),
  ADD KEY `fk_Empresas_Persona1_idx` (`idPersona`);

--
-- Indices de la tabla `licitacion`
--
ALTER TABLE `licitacion`
  ADD PRIMARY KEY (`idLicitacion`),
  ADD KEY `fk_Liquidacion_Contrato_Persona1_idx` (`idPersona`),
  ADD KEY `fk_Licitacion_Empresas1_idx` (`idEmpresas`),
  ADD KEY `fk_Licitacion_Contatos_Publicos1_idx` (`idContatos_Publicos`);

--
-- Indices de la tabla `persona`
--
ALTER TABLE `persona`
  ADD PRIMARY KEY (`idPersona`),
  ADD UNIQUE KEY `idPersona_UNIQUE` (`idPersona`),
  ADD KEY `fk_Persona_Secretarias1_idx` (`idSecretarias`);

--
-- Indices de la tabla `registro_actas`
--
ALTER TABLE `registro_actas`
  ADD PRIMARY KEY (`idRegistro_Actas`),
  ADD KEY `fk_Registro_Actas_Persona1_idx` (`idPersona`);

--
-- Indices de la tabla `secretarias`
--
ALTER TABLE `secretarias`
  ADD PRIMARY KEY (`idSecretarias`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `contatos_publicos`
--
ALTER TABLE `contatos_publicos`
  MODIFY `idContatos_Publicos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT de la tabla `documentos`
--
ALTER TABLE `documentos`
  MODIFY `idDocumentos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `empresas`
--
ALTER TABLE `empresas`
  MODIFY `idEmpresas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT de la tabla `licitacion`
--
ALTER TABLE `licitacion`
  MODIFY `idLicitacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT de la tabla `persona`
--
ALTER TABLE `persona`
  MODIFY `idPersona` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT de la tabla `registro_actas`
--
ALTER TABLE `registro_actas`
  MODIFY `idRegistro_Actas` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT de la tabla `secretarias`
--
ALTER TABLE `secretarias`
  MODIFY `idSecretarias` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `contatos_publicos`
--
ALTER TABLE `contatos_publicos`
  ADD CONSTRAINT `fk_Contatos_Publicos_Persona1` FOREIGN KEY (`idPersona`) REFERENCES `persona` (`idPersona`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `documentos`
--
ALTER TABLE `documentos`
  ADD CONSTRAINT `fk_documentos_Licitacion` FOREIGN KEY (`idLicitacion`) REFERENCES `licitacion` (`idLicitacion`);

--
-- Filtros para la tabla `empresas`
--
ALTER TABLE `empresas`
  ADD CONSTRAINT `fk_Empresas_Persona1` FOREIGN KEY (`idPersona`) REFERENCES `persona` (`idPersona`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `licitacion`
--
ALTER TABLE `licitacion`
  ADD CONSTRAINT `fk_Licitacion_Contatos_Publicos1` FOREIGN KEY (`idContatos_Publicos`) REFERENCES `contatos_publicos` (`idContatos_Publicos`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Licitacion_Empresas1` FOREIGN KEY (`idEmpresas`) REFERENCES `empresas` (`idEmpresas`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Liquidacion_Contrato_Persona1` FOREIGN KEY (`idPersona`) REFERENCES `persona` (`idPersona`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `persona`
--
ALTER TABLE `persona`
  ADD CONSTRAINT `fk_Persona_Secretarias1` FOREIGN KEY (`idSecretarias`) REFERENCES `secretarias` (`idSecretarias`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `registro_actas`
--
ALTER TABLE `registro_actas`
  ADD CONSTRAINT `fk_Registro_Actas_Persona1` FOREIGN KEY (`idPersona`) REFERENCES `persona` (`idPersona`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
